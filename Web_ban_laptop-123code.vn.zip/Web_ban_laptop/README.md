# Web_ban_laptop
trang web bán hàng laptop, ngôn ngữ sử dụng: html/css javascript, lưu trữ dữ liệu bằng localStorage
